# Contrôles permanents – Guide de montage Power BI

Contenu du kit :

| Fichier | Rôle |
|---|---|
| `donnees/*.csv` | Jeu de données d'exemple (5 volets, 15 contributeurs, 6 arrêtés avr→sept 2026). Forbearance ≈ 102,2 M€ / 98 contrats / 15 contributeurs |
| `theme_controles_permanents.json` | Thème (couleurs, polices, style des tableaux) |
| `fond_controles_permanents.png` | Image de fond 1920×1080 (sidebar, cartes, icônes KPI) |
| `maquette_zones.png` | Même fond annoté avec la position X/Y/L/H de chaque visuel |
| `mesures_DAX.dax` | Toutes les tables calculées et mesures |

---

## 1. Données et modèle

1. **Obtenir les données > Texte/CSV** : importer les 4 fichiers (séparateur `;`, encodage UTF-8). Dans `Fait_Encours`, régler `Encours` en *Nombre décimal* avec les paramètres régionaux **Français** (virgule décimale).
2. Créer la requête vide `DerniereActualisation` :
   `= #table(type table [Horodatage = datetime], {{DateTime.LocalNow()}})`
3. Créer les tables calculées `Dim_Date` et `Dim_Contrib_Donut` (voir le fichier DAX). Marquer `Dim_Date` comme table de dates, trier `Mois` par `MoisNum`, trier `Dim_Volet[Volet]` par `Ordre`.
4. Relations (toutes en *plusieurs à un*, filtrage *unique*) :
   - `Fait_Encours[ID_Contrat]` → `Dim_Contrat[ID_Contrat]`
   - `Dim_Contrat[Contributeur]` → `Dim_Contributeur[Contributeur]`
   - `Dim_Contrat[Volet]` → `Dim_Volet[Volet]`
   - `Fait_Encours[Date_Arrete]` → `Dim_Date[Date]`
   - `Dim_Contrib_Donut` : **aucune relation**
5. Créer une table vide `_Mesures` et y coller les mesures (ou via Tabular Editor). Formats :
   - `Encours dernier arrêté` → `#,0.0,, "M€"`
   - `Encours (M€)` → `0.00 "M€"`
   - `Encours`, `Encours dernier point`, `Encours Anneau` → `#,0.0,, "M€"`

## 2. Page

1. **Affichage > Thèmes > Rechercher des thèmes** → `theme_controles_permanents.json`.
2. Format de page : **Taille du canevas = Personnalisé 1920 × 1080**.
3. **Arrière-plan du canevas** : image `fond_controles_permanents.png`, ajustement **Ajuster**, transparence **0 %**.
4. Renommer les pages : Synthèse, Contrôles, Contrats, Contributeurs, Annexes (dupliquer la page pour garder le fond).

Utiliser `maquette_zones.png` pour placer chaque visuel : *Format > Général > Propriétés > Taille et position*.

## 3. Visuels, un par un

### En-tête
- **Zone de texte** (X 246, Y 14) : « Contrôles permanents » Segoe UI Bold 28, puis « Production sur dernier arrêté des secteurs pétrole et charbon » 16, couleur `#3B1F6E`.
- **Carte (nouvelle)** (X 1600, Y 18) : `Libellé dernière MAJ`, sans fond, police 13.

### Navigation (sidebar)
- **Insérer > Boutons > Navigateur > Navigateur de pages**, X 10 Y 140 L 172 H 330, orientation verticale.
- État *Par défaut* : remplissage transparent, texte blanc 13. État *Sélectionné* : remplissage `#7C3AED`, coins arrondis 10. Ajouter les icônes en option (Icône > Personnalisé).

### Volet (le sélecteur en haut)
- Texte « Volet » (Segoe UI Bold 18) à gauche du bandeau.
- **Segment de boutons** (button slicer) sur `Dim_Volet[Volet]`, X 330 Y 106 L 1150 H 48, 1 ligne × 5 colonnes.
- Sélection : **Sélection unique + Forcer la sélection**, valeur par défaut Forbearance.
- Style *Par défaut* : fond blanc, bordure `#D8CCF5`, rayon 14. *Sélectionné* : fond `#4C1D95`, texte blanc gras.

### Filtres
- 3 **segments en liste déroulante** : `Dim_Contributeur[Bassin]`, `Dim_Contributeur[Etablissement]`, `Dim_Contrat[Secteur]`. En-têtes « Bassin », « Établissement », « Secteur économique ».
- **Réinitialiser les filtres** : vider les 3 segments → *Signets > Ajouter* « Reset » → options : décocher *Affichage*, cocher *Données*, **Visuels sélectionnés** (les 3 segments sélectionnés). Bouton *Réinitialiser* (icône) → Action *Signet* « Reset ». Astuce : bouton vide + Ctrl+clic en mode édition.

### Cartes KPI (nouvelle carte, fond transparent)
Décaler la zone de valeur de ~80 px à droite de l'icône (ou placer la carte à X+80).

| Carte | Valeur | Titre (fx > Valeur du champ) |
|---|---|---|
| 1 | `Encours dernier arrêté` + sous-libellé « Somme des expositions » | `Titre Encours global` |
| 2 | `Nb contrats` | `Titre Nb contrats` |
| 3 | `Contributeurs concernés` | « Contributeurs concernés » (fixe) |
| 4 | `Dossiers à traiter` | `Titre Dossiers à traiter` |

Valeur : Segoe UI Bold 30. Titre : Semibold 13, **retour à la ligne activé**.

### Encours par contributeur (Top 7)
- **Graphique à barres groupées** : Axe Y `Dim_Contributeur[Contributeur]`, Axe X `Encours (M€)`.
- Volet Filtres : `Contributeur` → **N premiers = 7** par `Encours (M€)`.
- Couleur `#7C3AED` (ou dégradé fx : min `#C4B5FD`, max `#5B2A9E`). Étiquettes de données ON. Titre axe X « Encours (M€) ».

### Répartition (anneau)
- **Anneau** : Légende `Dim_Contrib_Donut[Contributeur]`, Valeurs `Encours Anneau`.
- Couleurs : 1 `#4C1D95`, 2 `#8B5CF6`, 3 `#A78BFA`, 4 `#C4B5FD`, Autres `#D9D9E3`.
- Étiquettes : *Pourcentage du total*, position extérieure ; rayon intérieur ~65 %. Légende à droite.
- Centre : **carte** superposée et transparente avec `Encours dernier arrêté` + libellé « Encours ».
- Titre fx : `Titre Répartition`.

### Évolution (courbe)
- **Graphique en courbes** : Axe X `Dim_Date[Mois]` (type catégoriel), Axe Y `Encours`, **plus** `Encours dernier point` comme 2e série.
- Série 1 : `#7C3AED`, marqueurs ON, étiquettes OFF, *zone ombrée* ON (transparence 85 %).
- Série 2 : même couleur, marqueur plus gros, **étiquettes ON** avec fond `#7C3AED`, texte blanc → seul le dernier point affiche « 102,4 M€ ».
- Axe Y min 80 M€, légende OFF. Titre fx : `Titre Évolution`.

### Détail des contributeurs (tableau)
- **Tableau** : `Dim_Contributeur[Contributeur]`, `Nb contrats`, `Encours dernier arrêté` (format `#,0.00 €`), `Statut agrégé`, `Priorité agrégée`.
- Renommer les colonnes dans le visuel : Contributeur, Nombre de contrats, Somme des expositions, Statut, Priorité.
- Mise en forme conditionnelle (*Couleur d'arrière-plan* et *Couleur de police* > fx > Valeur du champ) :
  - Statut → `Couleur fond Statut` / `Couleur texte Statut`
  - Priorité → `Couleur fond Priorité` / `Couleur texte Priorité`
- Alignement centré pour Statut et Priorité. Total ON (le thème l'affiche en violet foncé, texte blanc).
- Titre fx : `Titre Détail`.

### Panneau Power Apps
1. Insérer le **visuel Power Apps** (X 1362, Y 270, L 546, H 790).
2. Champs : `Dim_Contrat[ID_Contrat]`, `Dim_Contrat[Contributeur]`, `Dim_Contrat[Statut]`, `Dim_Contrat[Priorite]`, `Encours dernier arrêté`.
3. **Créer** → l'app reçoit `PowerBIIntegration.Data` (filtrée par le volet et les segments).
4. Dans l'app (format 546×790, fond `#FFFFFF`) :
   - Compteurs : `CountRows(Filter(PowerBIIntegration.Data, Statut = "À traiter"))`, idem pour Soumis et Validé.
   - Formulaire du plan d'action (Libellé, Échéance, Avancement %, Commentaire) → liste SharePoint ou table Dataverse `PlanActions`.
   - Galerie « Éléments à valider » avec cases à cocher → collection `colSelection`, libellé `"(sélection : " & CountRows(colSelection) & ")"`.
   - **Soumettre** : `ForAll(colSelection, Patch(...)); PowerBIIntegration.Refresh()`.
   - **Ouvrir l'app** : `Launch("https://apps.powerapps.com/play/<AppId>")`.
5. Le statut étant modifié par l'app, pointer à terme `Dim_Contrat[Statut]` vers la même source (SharePoint/Dataverse) au lieu du CSV.

## 4. Brancher les vraies données
Remplacer les sources CSV par tes tables (Power Query > Paramètres de la source) en gardant les noms de colonnes : `ID_Contrat, Date_Arrete, Encours` (fait) et `Volet, Contributeur, Secteur, Statut, Priorite` (contrat). Toutes les mesures continueront de fonctionner.
