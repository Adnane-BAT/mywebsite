/* Mini-runtime autonome pour ouvrir les maquettes AEGIS hors du canevas */
(function () {
  window.DCLogic = class { constructor(props) { this.props = props || {}; this.state = {}; } setState(s) { Object.assign(this.state, s); } };
  function lookup(scope, path) {
    path = path.trim();
    if (path === 'true') return true; if (path === 'false') return false;
    return path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), scope);
  }
  function interp(str, scope) {
    return str.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (_, p) => { const v = lookup(scope, p); return v == null ? '' : v; });
  }
  function proc(node, scope) {
    if (node.nodeType === 3) { if (node.nodeValue.includes('{{')) node.nodeValue = interp(node.nodeValue, scope); return; }
    if (node.nodeType !== 1) return;
    const tag = node.localName.toLowerCase();
    if (tag === 'sc-for') {
      const m = /\{\{\s*([^}]+?)\s*\}\}/.exec(node.getAttribute('list') || '');
      const list = m ? lookup(scope, m[1]) || [] : [];
      const as = node.getAttribute('as') || 'item';
      const parent = node.parentNode;
      list.forEach((it, i) => {
        const s = Object.assign(Object.create(scope), { [as]: it, $index: i });
        Array.from(node.childNodes).forEach(c => { const cl = c.cloneNode(true); parent.insertBefore(cl, node); proc(cl, s); });
      });
      parent.removeChild(node); return;
    }
    if (tag === 'sc-if') {
      const m = /\{\{\s*([^}]+?)\s*\}\}/.exec(node.getAttribute('value') || '');
      const ok = m ? lookup(scope, m[1]) : false; const parent = node.parentNode;
      if (ok) Array.from(node.childNodes).forEach(c => { parent.insertBefore(c, node); proc(c, scope); });
      parent.removeChild(node); return;
    }
    Array.from(node.attributes).forEach(a => { if (a.value.includes('{{')) node.setAttribute(a.name, interp(a.value, scope)); });
    Array.from(node.childNodes).forEach(c => proc(c, scope));
  }
  document.addEventListener('DOMContentLoaded', () => {
    const sc = document.querySelector('script[data-dc-script]');
    const decl = JSON.parse(sc.getAttribute('data-props') || '{}'); const props = {};
    Object.keys(decl).forEach(k => { if (k[0] !== '$' && 'default' in decl[k]) props[k] = decl[k].default; });
    const Component = new Function('DCLogic', sc.textContent + '\nreturn Component;')(window.DCLogic);
    const vals = new Component(props).renderVals();
    const root = document.querySelector('x-dc');
    const helmet = root.querySelector('helmet');
    if (helmet) { Array.from(helmet.childNodes).forEach(c => document.head.appendChild(c)); helmet.remove(); }
    Array.from(root.childNodes).forEach(c => proc(c, vals));
    Array.from(root.childNodes).forEach(c => root.parentNode.insertBefore(c, root)); root.remove();
  });
})();
