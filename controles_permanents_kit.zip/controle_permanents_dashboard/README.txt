TABLEAU DE BORD - CONTRÔLES PERMANENTS

1) Ouvrir index.html dans un navigateur : maquette interactive.
2) Dans Power BI Desktop : Accueil > Obtenir des données > Texte/CSV > contributeurs.csv.
3) Modélisation > Nouvelle mesure : copier les expressions de mesures_dax.txt.
4) Affichage > Thèmes > Parcourir les thèmes : charger theme_powerbi.json.
5) Créer une page de synthèse avec les quatre KPI, barres des contributeurs, répartition par groupe et table.

IMPORTANT : ce kit n'est PAS un fichier PBIX et ne contient pas le modèle d'origine.
Les données ont été recopiées depuis des photos, elles ne sont pas garanties exactes.
Les filtres Bassin / Établissement / Secteur économique et les 13 onglets de contrôle ne peuvent pas être reproduits sans les données de départ.
Pour générer le rapport final, transmettre le PBIX ou les tables et la structure du modèle.
